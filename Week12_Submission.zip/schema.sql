PRAGMA foreign_keys = ON;

CREATE TABLE clinics (
    clinic_id TEXT PRIMARY KEY,
    clinic_name TEXT NOT NULL UNIQUE,
    region TEXT NOT NULL
);

CREATE TABLE patients (
    patient_id TEXT PRIMARY KEY,
    birth_year INTEGER NOT NULL,
    preferred_language TEXT NOT NULL,
    social_needs_flag INTEGER NOT NULL CHECK (social_needs_flag IN (0, 1))
);

CREATE TABLE encounters (
    encounter_id TEXT PRIMARY KEY,
    patient_id TEXT NOT NULL,
    clinic_id TEXT NOT NULL,
    encounter_date TEXT NOT NULL,
    visit_type TEXT NOT NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
    FOREIGN KEY (clinic_id) REFERENCES clinics(clinic_id)
);

CREATE TABLE referrals (
    referral_id TEXT PRIMARY KEY,
    encounter_id TEXT NOT NULL,
    service_type TEXT NOT NULL,
    referral_date TEXT NOT NULL,
    priority TEXT NOT NULL CHECK (priority IN ('Routine', 'High')),
    due_date TEXT NOT NULL,
    FOREIGN KEY (encounter_id) REFERENCES encounters(encounter_id)
);

CREATE TABLE followups (
    followup_id TEXT PRIMARY KEY,
    referral_id TEXT NOT NULL UNIQUE,
    completion_date TEXT,
    outcome TEXT NOT NULL CHECK (outcome IN ('Completed', 'Completed on time', 'Completed late', 'Pending', 'Cancelled', 'Declined')),
    contact_attempts INTEGER NOT NULL CHECK (contact_attempts >= 0),
    FOREIGN KEY (referral_id) REFERENCES referrals(referral_id)
);
